# BizPilot — Smart Business Assistant

A full-stack business workspace for small/local businesses to manage customers, leads, sales and marketing content.

## Features
- Business dashboard and revenue metrics
- Customer management
- Lead pipeline with status updates
- Follow-up dates
- Product/service catalogue API
- Sales records
- Social-media post generator
- SQLite persistence
- Responsive UI

## Stack
HTML/CSS/JavaScript · Node.js · Express · SQLite

## Run
```bash
npm install
npm start
```
Open `http://localhost:3001`.

## Resume bullet
Developed **BizPilot**, a full-stack business management assistant using Node.js, Express and SQLite to manage customer enquiries, lead conversion, sales metrics and automated social-media content generation.

## API
GET `/api/stats`, `/api/customers`, `/api/leads`, `/api/products`, `/api/sales`
POST `/api/customers`, `/api/leads`, `/api/products`, `/api/sales`, `/api/content`
PATCH `/api/leads/:id`
